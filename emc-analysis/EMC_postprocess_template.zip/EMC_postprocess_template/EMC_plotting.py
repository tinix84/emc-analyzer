import numpy as np
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle
#import ipywidgets as widgets
from IPython.display import display
import os
import shutil
from PIL import Image
import time

from Standards import *
from Support_functions import *

dir_path = os.path.dirname(os.path.realpath(__file__))

#########################################################
# General settings

# Enter the operating point title here
selection_of_titles = [" OP1: everything off",
                        "OP2: LV power supply 14V on, CAN on",
                        "OP3: LV power supply 14V on, CAN on, HS: 800V, Stby",
                        "OP4: LS: 415V, 20A, HS: 830V, 10A",
                        "OP6: LS: 400V, 480A, HS: 800V, 240A"]


# Enter the signals with HF data available
HF_available_meas = ["LV_neg", "LV_pos", "HS_neg", "HS_pos", "LS_neg", "LS_pos"]
type = "LV3"  # possible values: "LV2", "LV3", "LV4", "LV5", "AC", "HV". It will be adpated in the code
savefig = 1  # 0 = not saving images, 1 = saving images into the assigned folder
plot_folder = "Comparison_plots/"  # plots folder
data_folder = "/data/"
showfig = 0  # enables the figure show
show_limits = 0  # show the final figure
copy_to_external_folder = 0
ext_folder_path = r"C:\Users\jfe01.BRUSA\Desktop\OBC7xx\EMC results\Documentation\images\product"
rotate = 0  # rotate the image before copying it
typst_edit = 0  # generates the data structure to import images
images_filename = "typst.txt"
ppt = 1  # generate the powerpoint
single = 1  # the graph will be with a single trace (if 1 put the same file_names on file_names list
            # and leave the legend entries empty with "")

#####################################################################
total_elapsed_time  = 0
result = 0
fp = open("results.txt", "w")
fp.write("OP Port Result Freq Margin Cutoff_pole Detector Average\n")
# REAL POST PROCESSING
for k, op in enumerate(["OP1", "OP2", "OP3", "OP4", "OP6"]):
    # for each operating point defined
    for meas in ["LV_neg", "LV_pos", "HS_neg", "HS_pos", "LS_pos", "LS_neg"]:
        # for each measurement

        # Define name of files to be plotted as well as plot order (no extension)
        file_names = ["240429_GM_B_" + str(op) + "_" + str(meas),
                      "240429_GM_B_" + str(op) + "_" + str(meas)]
        print(f"processing: {file_names}")
        # leave legend_entreis empty when plotting single spectrum (no comparison)
        legend_entries = ["",
                          ""]
        plot_order = [1, 1]
        plot_title = ["BDC6 GM - " + selection_of_titles[k] + " - " + meas]
        y_limit = [-10, 100]
        # Define parent folder; end with "/"
        parent_folder = "/"

        try:
            result = True
            xticks = [0.15, 1, 10, 108]
            elapsed_time, result, freq, margin, wc_violation, detector, spectrum_avg = pp(data_folder, file_names, plot_order, meas,
                    dir_path, legend_entries, savefig, showfig,
                    plot_title, plot_folder, HF_available_meas, single, meas)
        
            # Save the result into a file
            for res, f, mar,wc, det in zip(result, freq, margin, wc_violation, detector):
                fp.write(f"{file_names[1]} {res}: {f}MHz {mar:.2f}dBuV {wc:.3f}MHz {det} {spectrum_avg}dBuV\n")

            total_elapsed_time += elapsed_time

        except Exception as e:
            print(e)
    
fp.close()

print(f"Total elapsed time: {total_elapsed_time} [s]")

if show_limits:

    # Create the updated plot
    plt.figure(figsize=(10, 6))
    plt.plot(CISPR_25_range_f, CISPR_25_2_average, marker='o', label='Average')
    plt.plot(CISPR_25_range_f, CISPR_25_2_peak, marker='x', label='Peak')
    plt.xlabel('Frequency [MHz]')
    plt.ylabel('CISPR 25 Values')
    plt.title('CISPR 25 Average and Peak Values')
    plt.grid(True)
    plt.legend()
    plt.xlim(0.15, 108)  # Set the X-axis limits
    plt.show()


if rotate:
    # for each image
    source_folder =  dir_path + "\\" + plot_folder.replace("/", "")
    print(source_folder)
    for file_name in os.listdir(source_folder):
        # construct full file path
        source = source_folder + "\\" + file_name
        # rotate images
        base_name, extension = os.path.splitext(file_name)
        if extension == ".png":
            Original_Image = Image.open(source)
            # Rotate Image By270 Degree
            rotated_image = Original_Image.transpose(Image.ROTATE_270)
            # save a image using extension
            rotated_image.save(source)
            print(f"Image rotated {source}")


if copy_to_external_folder:

    source_folder =  dir_path + r"\\" + plot_folder.replace("\"", "")
    destination_folder = ext_folder_path + r"\\"

    # fetch all files
    for file_name in os.listdir(source_folder):
        # construct full file path
        source = source_folder + file_name
        destination = destination_folder + file_name
        # copy only files
        if os.path.isfile(source):
            shutil.copy(source, destination)
            print(f"copied {file_name} in {destination}")

if typst_edit:  # generates the data structure to import images
    images = []
    for file_name in os.listdir(source_folder):
        images.append(file_name)

    with open(images_filename, 'w') as f:
        f.write("#let data = (")
        for i, image in enumerate(images):
            f.write(f"(title: \"Title {i}\", images: ")
            f.write("\n")
            f.write(f"(\"\images\product\{image}\",)),\n")

        f.write(")")
    print("Typst data file generated!!")

if ppt:
    import pptx  
    import os

    pptx_start_doc = r"single_master.pptx"

    # Create a new PowerPoint presentation
    prs = pptx.Presentation(pptx_start_doc)

    # Set the path to the folder containing the images
    folder_path = dir_path + "\Comparison_plots"

    # Get the slide width and height
    slide_width = prs.slide_width
    slide_height = prs.slide_height

    ## ADD Result report
    # extract data from results.txt file
    with open("results.txt", "r") as fp:
        data = get_data(fp)

    from pptx.util import Inches
    rows, cols = len(data), len(data[0])
    left = Inches(0.4)
    top = Inches(0.4)
    width = Inches(12.5)
    height = Inches(0.8)
  
    slide_layout = prs.slide_layouts[18]
    slide = prs.slides.add_slide(slide_layout)

    table = slide.shapes.add_table(rows, cols, left, top, width, height).table

    from pptx.dml.color import RGBColor

    for i, row in enumerate(data):
        for j, val in enumerate(row):
            cell = table.cell(i, j)
            cell.text = str(val)
            if j == 6:
                paragraph = cell.text_frame.paragraphs[0]
                run = paragraph.runs[0]
                if str(val) == "PASSED":
                    run.font.color.rgb = RGBColor(0, 128, 0)
                if str(val) == "FAILED":
                    run.font.color.rgb = RGBColor(255, 0, 0)

    image_list = []
    # Iterate over the files in the folder
    for filename in os.listdir(folder_path):
        # Check if the file is an image
        if filename.endswith('.BMP') or filename.endswith('.bmp') or filename.endswith('.png'):
            image_list.append(filename)

    print(image_list)

    for i in range(0,int(len(image_list))):
        # Add the image to a new slide
        slide_layout = prs.slide_layouts[18]  # layout single image
        slide = prs.slides.add_slide(slide_layout)
        img_path1 = os.path.join(folder_path, image_list[i])
        left = pptx.util.Cm(0)
        top = pptx.util.Cm(2.93)
        width = pptx.util.Cm(33.55)
        height = pptx.util.Cm(15.51)
        pic1 = slide.shapes.add_picture(img_path1, left, top, width=width, height=height)
        subtitle = slide.placeholders[0]
        subtitle.text = img_path1.split('\\')[-1].split('.')[0]

    # Save the PowerPoint presentation
    prs.save(r'C:\Users\jfe01.BRUSA\Desktop\BDC6xx\EMC\Capo.pptx')

    print("End")