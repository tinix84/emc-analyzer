import pptx  
import os

pptx_start_doc = r"single_master.pptx"

# Create a new PowerPoint presentation
prs = pptx.Presentation(pptx_start_doc)

# Set the path to the folder containing the images
folder_path = r"C:\Users\jfe01.BRUSA\Desktop\OBC7xx\OBC764\EMC"

# Get the slide width and height
slide_width = prs.slide_width
slide_height = prs.slide_height

image_list = []
# Iterate over the files in the folder
for filename in os.listdir(folder_path):
  # Check if the file is an image
  if filename.endswith('.BMP') or filename.endswith('.bmp') or filename.endswith('.png'):
    image_list.append(filename)

print(image_list)

for i in range(0,int(len(image_list))):
    # Add the image to a new slide
    slide_layout = prs.slide_layouts[10]  # layout single image
    slide = prs.slides.add_slide(slide_layout)
    img_path1 = os.path.join(folder_path, image_list[i])
    for shape in slide.placeholders:
       if shape.placeholder_format.type == 7:
          ph = shape
          break
       
    left = ph.left
    top = ph.top
    width = ph.width
    height = ph.height

    pic1 = slide.shapes.add_picture(img_path1, left, top, width=width, height=height)

    subtitle = slide.placeholders[0]
    subtitle.text = img_path1.split('\\')[-1].split('.')[0]

    ## Add text
    textbox = [s for s in slide.shapes if s.has_text_frame][1]
    textbox.text = "PASSED"

# Save the PowerPoint presentation
prs.save(r'C:\Users\jfe01.BRUSA\Desktop\OBC7xx\OBC764\EMC\presentation_new_bravo_jitter.pptx')

print("End")

