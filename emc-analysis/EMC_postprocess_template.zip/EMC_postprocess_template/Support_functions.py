import numpy as np
import os
import matplotlib.pyplot as plt
import time

from Standards import *
from functools import reduce

from Standards import calculate_threshold

def difference(f1,a1,f2,a2):
    """ This function calculates a1-a2.
    f lists contain frequency data
    a lists contain amplitude data. """

    f = []
    a = []

    for freq, amp in zip(f1, a1):
        f.append(freq)
        a.append(amp-calculate_threshold(f2, a2, freq))

    return f,a

def spectrum_average(spectrum, limit):
    """ This function calculates the average of the difference 
    between the spectrum and the limits. Advanced post process
    will come in a second moment. """

    # Get Masks
    CISPR_range_f, CISPR_average, CISPR_peak, CISPR_label = get_cispr_limits(limit)

    # Get spectra (peak and average)
    freq_list = spectrum[:, 0].flatten().tolist()[0]
    pk_list = spectrum[:, 1].flatten().tolist()[0]
    avg_list = spectrum[:, 2].flatten().tolist()[0]

    # Calculate the difference (PEAK)
    diff_f, diff_a = difference(freq_list, pk_list, CISPR_range_f, CISPR_peak) 

    # Calculate the average on the entire span (PEAK)
    return np.mean(diff_a)


def worst_case_cutoff_freq(spectrum, limit):
    """ This function calculates the worst case cutoff frequency """

    # Get Masks
    CISPR_range_f, CISPR_average, CISPR_peak, CISPR_label = get_cispr_limits(limit)

    # Get spectra (peak and average)
    freq_list = spectrum[:, 0].flatten().tolist()[0]
    pk_list = spectrum[:, 1].flatten().tolist()[0]
    avg_list = spectrum[:, 2].flatten().tolist()[0]

    # Peak analysis [MHz]
    wc_pk_list = []

    for i,f in enumerate(freq_list):
        thr = calculate_threshold(CISPR_range_f, CISPR_peak, f)
        if pk_list[i] > thr:
            # Add worst case frequency pole
            wc_pk_list.append(f/(pk_list[i]-thr))

    # Avg analysis [MHz]
    wc_avg_list = []

    for i,f in enumerate(freq_list):
        thr = calculate_threshold(CISPR_range_f, CISPR_average, f)
        if avg_list[i] > thr:
            # Add worst case frequency pole
            wc_avg_list.append(f/(avg_list[i]-thr))


    if wc_pk_list == [] and wc_avg_list == []:
        return 0

    if wc_avg_list == []:
        return min(wc_pk_list)
    
    if wc_pk_list == []:
        return min(wc_avg_list)

    return min(min(wc_pk_list), min(wc_avg_list))


def get_data(fp):
    """ This function gets the data from the result.txt file """
    rows = fp.readlines()
    data = []
    for row in rows:
        line = row.split(" ")
        if line[1][:-1] == "True":
            result =  "PASSED"
        else:
            result = "FAILED"
        data.append([line[0].split("_")[3:4], line[0].split("_")[-2:], line[5], line[2], line[3], line[4], result])
        
        if line[0] == "OP":
            data.append([line[0], line[1], line[6], line[3], line[4], line[5], line[2]])

    data.pop(0)

    return data

def unique_by_x(matrix):

    arr = np.asarray(matrix)
    x_vals = arr[:, 0]

    _,idx = np.unique(x_vals, return_index=True)
    
    return matrix[np.sort(idx)]

def merge_unique_matrices(matrices):
    merged_1 = np.vstack((matrices[0], matrices[1]))
    merged_2 = np.vstack((matrices[2], matrices[3]))
    return [unique_by_x(merged_1), unique_by_x(merged_2)]

def swapPositions(list, pos1, pos2):
     
    list[pos1], list[pos2] = list[pos2], list[pos1]
    return list

def unique(list1):

    # Print directly by using * symbol
    ans = reduce(lambda re, x: re+[x] if x not in re else re, list1, [])

###########################################
########### SUPPORT FUNCTIONS #############

def find_and_open_file(filename, root_folder):
    """ This function searches for the file in the current directory
      and its subdirectories """

    # Search for the file in the current directory and its subdirectories
    for root, _, files in os.walk(root_folder):
        for file in files:
            base_name, extension = os.path.splitext(file)
            if extension != ".txt" and extension != ".TXT":
                continue
            if base_name == filename:
                filepath = os.path.join(root, file)
                return open(filepath, "r", encoding="latin-1")

    # File not found
    print("File not found: " + filename)
    return None

def find_largest_in_interval(x, y, fmin, fmax):
    """ This function finds the peak in the defined interval """

    freq = np.array(x)
    spectrum = np.array(y)
    mask = (freq >= fmin) & (freq >= fmax)
    
    if np.any(mask):
        max_index = np.argmax(spectrum[mask])
        max_freq = freq[mask][max_index]
        max_value = spectrum[mask][max_index]
        return [max_freq], [max_value]
    else:
        return None, None



def find_largest_per_decade(x, y):
    """ This function finds the largest value per decade """

    # Create an empty list to store the results
    decade_x = []
    decade_y = []

    # Convert x to logarithmic scale
    log_x = np.log10(x)

    # Iterate through each decade
    for decade in range(0, int(log_x[-1]) + 2): 
        # Find indices corresponding to the current decade
        indices = np.where((log_x >= decade - 1) & (log_x < decade))[0]

        if indices.size > 0:
            # Find the maximum value and its corresponding index in this decade
            max_index = indices[np.argmax(y[indices])]

            # Append the values to the result arrays
            decade_x.append(x[max_index])
            decade_y.append(y[max_index])

    return np.array(decade_x), np.array(decade_y)

def find_smallest_per_decade(x, y):
    """ This function finds the smallest value per decade """

    # Create an empty list to store the results
    decade_x = []
    decade_y = []

    # Convert x to logarithmic scale
    log_x = np.log10(x)

    # Iterate through each decade
    for decade in range(0, int(log_x[-1]) + 1): #1
        # Find indices corresponding to the current decade
        indices = np.where((log_x >= decade - 1) & (log_x < decade))[0]

        if indices.size > 0:
            # Find the maximum value and its corresponding index in this decade
            max_index = indices[np.argmin(y[indices])]

            # Append the values to the result arrays
            decade_x.append(x[max_index])
            decade_y.append(y[max_index])

    return np.array(decade_x), np.array(decade_y)

def get_cispr_limits(type):

    # Create numpy arrays
    if(type == "LV2"):
        CISPR_range_f = np.array(CISPR_25_range_f)
        CISPR_average = np.array(CISPR_25_2_average)
        CISPR_peak    = np.array(CISPR_25_2_peak)
        CISPR_label   = "CISPR 25 - class 2"

    if(type == "LV3"):
        CISPR_range_f = np.array(CISPR_25_range_f)
        CISPR_average = np.array(CISPR_25_3_average)
        CISPR_peak    = np.array(CISPR_25_3_peak)
        CISPR_label   = "CISPR 25 - class 3 LV"

    if(type == "LV4"):
        CISPR_range_f = np.array(CISPR_25_range_f)
        CISPR_average = np.array(CISPR_25_4_average)
        CISPR_peak    = np.array(CISPR_25_4_peak)
        CISPR_label   = "CISPR 25 - class 4"

    if(type == "LV5"):
        CISPR_range_f = np.array(CISPR_25_range_f)
        CISPR_average = np.array(CISPR_25_5_average)
        CISPR_peak    = np.array(CISPR_25_5_peak)
        CISPR_label   = "CISPR 25 - class 5"

    if(type == "AC"):
        CISPR_range_f = np.array(CISPR_AC_range_f)
        CISPR_average = np.array(CISPR_AC_average)
        CISPR_peak    = np.array(CISPR_AC_peak)
        CISPR_label   = "CISPR 32 - class B"

    if(type == "HV"):
        CISPR_range_f = np.array(CISPR_HV_range_f)
        CISPR_average = np.array(CISPR_HV_average)
        CISPR_peak    = np.array(CISPR_HV_peak)
        CISPR_label   = "CISPR 25 - class 3 - HV-LV decoupling class A5"

    return CISPR_range_f, CISPR_average, CISPR_peak, CISPR_label

def pp(data_folder, file_names: list, plot_order: list, meas,
             dir_path, legend_entries, savefig, showfig,
             plot_title, plot_folder, HF_available_meas, single, port):
    """ This function just plots trace """
    # trace type
    ac_scale = False

    if "LV" in port:
        type = "LV3"
    elif "HV" in port:
        type = "HV"
    else:
        type = "AC"
        ac_scale = True

    margin_report = []
    freq_out = []
    result = [True, True]
    failed_freq_ag = np.inf
    failed_freq_pk = np.inf
    pk_threshold_worst = np.inf
    ag_threshold_worst = np.inf
    qpeak = False
    # Read data from textfiles and store in np.matrix and list

    # Save timestamp
    start = time.time()

    data = []

    for f_name in file_names:

        # read base file: 100kHz - 30MHz
        file = find_and_open_file(f_name, dir_path+data_folder)
        if file is None:
            print(f"file {f_name} missing")
            return 0,0

        temp = np.empty((1,3))
        lines = file.readlines()
        for i, line in enumerate(lines):
            if i < 50:  # get rid of the header
                continue
            if i == 50: # labels
                labels = line.split(" ")
                labels.remove('\t')
                out_label = []
                for element in labels:
                    if element != '':
                        out_label.append(element.rstrip())
                labels = out_label
                # generate list for data allignment
                array = []
                for j, column in enumerate(labels):
                    if column == "Frequency":
                        array.append(j)
                    if column == "Peak":
                        array.append(j)
                    if column == "QPeak":
                        array.append(j)
                        qpeak = True
                    if column == "Avg":
                        array.append(j)

            if i in [50,51,52,53,54,55]:
                continue

            if qpeak and 1 in array:
                array.remove(1)

            values = line.strip().split()
            arr = np.fromstring(' '.join(values), dtype=float, sep=' ')
            arr = np.take(arr, array) # [0, 1, 2]
            arr = np.asmatrix(arr)
            temp = np.append(temp, arr, axis=0)

        temp = np.delete(temp, 0, 0)
        data.append(temp)
        file.close()

        if meas in HF_available_meas:

            # read HF file: 30MHZ - 108MHz
            f_name = f_name.split("_")
            # here you can specify the name structure of the HV file
            f_name = f_name[0] + "_" + f_name[1] + "_" + f_name[2] + "_200_" + f_name[3] + "_" + f_name[4] + "_" + f_name[5]

            print(f"f_name: {f_name}, dir_path: {dir_path}")

            file = find_and_open_file(f_name, dir_path)
            lines = file.readlines()
            for i, line in enumerate(lines):
                if i < 50:  # get rid of the header
                    continue
                if i == 50: # labels
                    labels = line.split(" ")
                    labels.remove('\t')
                    out_label = []
                    for element in labels:
                        if element != '':
                            out_label.append(element.rstrip())
                    labels = out_label
                    # generate list for data allignment
                    array = []
                    for j, column in enumerate(labels):
                        if column == "Frequency":
                            array.append(j)
                        if column == "Peak":
                            array.append(j)
                        if column == "QPeak":
                            array.append(j)
                            qpeak = True
                        if column == "Avg":
                            array.append(j)

                if i in [50,51,52,53,54,55]:
                    continue

                if qpeak and 1 in array:
                    array.remove(1)

                values = line.strip().split()
                arr = np.fromstring(' '.join(values), dtype=float, sep=' ')
                arr = np.take(arr, array) # [0, 1, 2]
                arr = np.asmatrix(arr)
                temp = np.append(temp, arr, axis=0)

            temp = np.delete(temp, 0, 0)
            data.append(temp)
            #merge_unique_matrices(data)
            file.close()

    if len(data) == 4:
        data = merge_unique_matrices(data)

    length = len(data)
    print(f"Number of traces to be processed: {length}")

    # worst case cutoff frequency
    wc_cutoff = worst_case_cutoff_freq(data[0], type)
    spectrum_avg = spectrum_average(data[0], type)


    #CISPR_range_f, CISPR_average, CISPR_peak, CISPR_label = get_cispr_limits(type)
    colormap = [[0.1608, 0.5020, 0.7255], [0.9059, 0.2980, 0.2353], [0.9020, 0.4941, 0.1333]]

    # Plot the data
    for i in range(1, max(plot_order) + 1):         # iterate over plots
        plot_idx = []
        for it, p in enumerate(plot_order):
            if(p == i):
                plot_idx.append(it)

        data_slice = [data[k] for k in plot_idx]

        # Create subplots with adjustable spacing
        fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(15, 6))

        # Plot CISPR limits
        # set type:
        CISPR_range_f, CISPR_average, CISPR_peak, CISPR_label = get_cispr_limits(type)
        ax1.semilogx(CISPR_range_f, CISPR_peak, 'r-', label=CISPR_label, linewidth=0.8)
        ax2.semilogx(CISPR_range_f, CISPR_average, 'r-', label=CISPR_label, linewidth=0.8)
        
        plt.subplots_adjust(wspace=0.15)

        curve1 = []
        anot1 = []
        anot1_extra =[]
        curve2 = []
        anot2 = []
        anot2_extra =[]

        for it, d in enumerate(data_slice):
            x      = np.asarray(d[:, 0]).squeeze()
            y_peak = np.asarray(d[:, 1]).squeeze()
            y_avg  = np.asarray(d[:, 2]).squeeze()

            failed_freq_ag = np.inf
            failed_freq_pk = np.inf
            pk_threshold_worst = np.inf
            ag_threshold_worst = np.inf

            # check the result (old)
            for x1, y_pk, y_ag in zip(x, y_peak, y_avg):
                pk_threshold = calculate_threshold(CISPR_range_f, CISPR_peak, x1)
                y_threshold = calculate_threshold(CISPR_range_f, CISPR_average, x1)


                if y_pk > pk_threshold:
                    result[0] = False
                    failed_freq_pk = min(failed_freq_pk, x1)
                    if failed_freq_pk == x1:
                        margin_pk = pk_threshold - y_pk
                        margin_report.append(margin_pk)
                else:
                    # find the worst safety margin
                    pk_threshold_worst = min(pk_threshold_worst, pk_threshold - y_pk)
                    if pk_threshold_worst == (pk_threshold - y_pk):
                        freq_threshold_worst_pk = x1


                if y_ag > y_threshold:
                    result[1] = False
                    failed_freq_ag = min(failed_freq_ag, x1)
                    if failed_freq_ag == x1:
                        margin_ag = y_threshold - y_ag
                        margin_report.append(margin_ag)
                else:
                    # find the worst safety margin
                    ag_threshold_worst = min(ag_threshold_worst, y_threshold - y_ag)
                    if ag_threshold_worst == (y_threshold - y_ag):
                        freq_threshold_worst_ag = x1

            if result[1]:
                # average
                margin_report.append(ag_threshold_worst)
                freq_out.append(freq_threshold_worst_ag)
            else:
                freq_out.append(failed_freq_ag)

            if result[0]:
                # peak
                margin_report.append(pk_threshold_worst)
                freq_out.append(freq_threshold_worst_pk)
            else:
                freq_out.append(failed_freq_pk)

            


            # magic stuff for pptx table
            # if margin_ag is not None:
            #     margin_report.append(margin_ag)
            # if margin_pk is not None:
            #     margin_report.append(margin_pk)


            # check the result (Riccardo)
            # for each frequency:
            # 1. subtract the two curves
            # 2. if SW_new > SW_old:  plot the distance between the limit
                    # if distance is positive:
                        # test passed
                    #else:
                        # is failed
                 #else:
                    # is passed


            # Plot 1: x-data vs. y-peak
            ax1_curve, = ax1.semilogx(x, y_peak, label=legend_entries[it], linewidth=0.8, zorder=-5)
            curve1.append(ax1_curve)
            # Plot 2: x-data vs. y-avg
            ax2_curve, = ax2.semilogx(x, y_avg, label=legend_entries[it], linewidth=0.8, zorder=-5)
            curve2.append(ax2_curve)

            # Annotate peak plot
            decade_x, decade_y = find_largest_per_decade(x, y_peak)
            for i2 in range(len(decade_x)):
                ax1.plot(decade_x[i2], decade_y[i2], 'rx')  # Cross marker
                ax1.annotate(f'{decade_y[i2]:.2f}', (decade_x[i2], decade_y[i2]),
                              textcoords="offset points", xytext=(10*it,10*it), ha='center')
                anot1.append([decade_x[i2], decade_y[i2]])

            # Annotate avg plot
            decade_x, decade_y = find_largest_per_decade(x, y_avg)
            for i2 in range(len(decade_x)):
                ax2.plot(decade_x[i2], decade_y[i2], 'rx')  # Cross marker
                ax2.annotate(f'{decade_y[i2]:.2f}', (decade_x[i2], decade_y[i2]),
                              textcoords="offset points", xytext=(-10*it,-10*it), ha='center')
                anot2.append([decade_x[i2], decade_y[i2]])

            # Annotate additional peaks (LV class 3 upper spectrum)

            decade_x, decade_y = find_largest_in_interval(x, y_peak, 10, 29)

            for i2 in range(len(decade_x)):
                ax1.plot(decade_x[i2], decade_y[i2], 'rx')  # Cross marker
                ax1.annotate(f'{decade_y[i2]:.2f}', (decade_x[i2], decade_y[i2]),
                              textcoords="offset points", xytext=(-10*it,-10*it), ha='center')
                anot1_extra.append([decade_x[i2], decade_y[i2]])


            decade_x, decade_y = find_largest_in_interval(x, y_avg, 10, 29)

            for i2 in range(len(decade_x)):
                ax2.plot(decade_x[i2], decade_y[i2], 'rx')  # Cross marker
                ax2.annotate(f'{decade_y[i2]:.2f}', (decade_x[i2], decade_y[i2]),
                              textcoords="offset points", xytext=(-10*it,-10*it), ha='center')
                anot2_extra.append([decade_x[i2], decade_y[i2]])


 

        if qpeak:
            ax1.set_title('EMC Qpeak')
        else:
            ax1.set_title('EMC Peak')
        ax2.set_title('EMC average')
        plt.suptitle(plot_title[i-1], fontsize=16, fontweight='bold')


    labels = ["peak", "avg"]
    software = ["old", "new"]
    data = {"peak": {"old": [[],[]],
                        "new": [[],[]]},
            "avg":  {"old": [[],[]],
                        "new": [[],[]]}
            }
    
    # extract the final data
    for curve,label in zip([curve1,curve2],labels):
        for i,sw in enumerate(software):
            data[label][sw][0] = curve[i].get_xdata()
            data[label][sw][1] = curve[i].get_ydata()


    # set type:
    
    CISPR_range_f, CISPR_average, CISPR_peak, CISPR_label = get_cispr_limits(type)

    # check the result (Riccardo)
            # for each peak:
            # 1. subtract the two curves
            # 2. if SW_new > SW_old:  plot the distance between the limit
                    # if distance is positive:
                        # test passed
                    #else:
                        # is failed
                 #else:
                    # is passed

    freqs1 = []
    freqs2 = []
    cell_text1 = []
    cell_text2 = []
    labels = ["peak", "avg"]
    tot = anot1+anot2
    for i, element in enumerate(tot):

        if i < len(tot)/2:
            # peak
            limit = calculate_threshold(CISPR_range_f, CISPR_peak, element[0])
            margin = limit - element[1]
            freqs1.append(element[0])
            cell_text1.append([element[0],limit,element[1],margin])
        else:
            # avg
            limit = calculate_threshold(CISPR_range_f, CISPR_average, element[0])
            margin = limit - element[1]
            freqs2.append(element[0])
            cell_text2.append([element[0],limit,element[1],margin])

    # set type:
  
    CISPR_range_f, CISPR_average, CISPR_peak, CISPR_label = get_cispr_limits(type)


    # append extra valuse in tables
    average = 0
    for anotate, freq, cell in zip([anot1_extra, anot2_extra], [freqs1, freqs2], [cell_text1, cell_text2]):
        if average:
            limit = calculate_threshold(CISPR_range_f, CISPR_average, anotate[0][0])
        else:
            limit = calculate_threshold(CISPR_range_f, CISPR_peak, anotate[0][0])
        margin = limit - anotate[0][1]
        freq.append(anotate[0][0])
        cell.append([anotate[0][0],limit,anotate[0][1],margin])
        average += 1
        
    l1 = len(cell_text1)
    l2 = len(cell_text2)


    # Pop the element of the second spectrum (not used for no comparison)
    """cell_text1[0].pop(3)
    cell_text1[1].pop(3)

    cell_text2[0].pop(3)
    cell_text2[1].pop(3)"""
    
    cell_text = [cell_text1, cell_text2]
    freqs = [freqs1, freqs2]

    table = []
    for cell in cell_text:
        # unique the elements of the table
        seen = set()
        cell_text_unique = []
        for row in cell:
            row_tuple = tuple(row)
            if row_tuple not in seen:
                seen.add(row_tuple)
                cell_text_unique.append(row)

        cell_text_unique = list(set(tuple(row) for row in cell))

        data_as_lists = [list(row) for row in cell_text_unique]

        table.append(data_as_lists)

    ####################################################

    #columns = ('Frequency [MHz]', 'Limit [dB$\mu$V]', 'Old SW [dB$\mu$V]',
    #           'New SW [dB$\mu$V]', 'Margin [dB$\mu$V]')
    
    columns = ('Frequency [MHz]', 'Limit [dB$\mu$V]',
               'Peak [dB$\mu$V]', 'Margin [dB$\mu$V]')
    freq = []
    margin = []
    type = []
    wc = []
    for i,ax in enumerate([ax1, ax2]):
        if single:
            unique_values = list(set(freqs[i]))
            rows = ['%d' % (j+1) for j,_ in enumerate(unique_values)]
        else:
            rows = ['%d' % (j+1) for j,_ in enumerate(freqs[i])]
        ax.set_xlabel('Frequency [MHz]')
        ax.set_ylabel(r'Measurement in [dB$\mu$V]')
        ax.legend(loc="upper right")
        if ac_scale:
            ax.set_ylim(0,80)
        else:
            ax.set_ylim(0,130)

        ax.grid(True)
        ax.minorticks_on()
        ax.grid(which='minor', linestyle=':', linewidth='0.5', color='gray')
        colors = plt.cm.BuPu(np.linspace(0, 0.5, len(rows)))

        plt.subplots_adjust(left=0.2, bottom=0.2)

        # Colours
        import matplotlib.colors as mcolors

        cell_colours = []
        for row in table[i]:
            if row[-1] < 0:
                cell_colours.append([mcolors.to_rgba('white')] * len(row))
            else:
                cell_colours.append([mcolors.to_rgba('white')] * len(row))
        
        # Find max violation
        maxi = 10000
        f = 0
        t = ""
        for data in table[i]:
            if data[3] < maxi:
                maxi = data[3]
                f = data[0]
                if i == 0:
                    t = "Peak"
                else:
                    t = "Avg"

        margin.append(maxi)
        freq.append([failed_freq_pk, failed_freq_ag])
        type.append(t)
        wc.append(wc_cutoff)

        # Add a table at the bottom of the axes
        the_table = ax.table(cellText=table[i],
                            rowLabels=rows,
                            rowColours=colors,
                            colLabels=columns,
                            loc='bottom',
                            bbox=[0, -0.25, 1, 0.18])  # 0, -0.18, 1, 0.18

    # Display the plots
    if savefig == 1:
        #plt.savefig(parent_folder +  file_names[0] + ".png", dpi=300)
        # Option 1
        # QT backend
        figure = plt.gcf()  # get current figure
        figure.set_size_inches(28, 11)
        plt.savefig(plot_folder + file_names[1] +".png", dpi=300)
    if showfig == 1:
        plt.show()

    # Save timestamp
    end = time.time()

    elapsed_time = end - start

    print(f"Elapsed time: {elapsed_time} [s]")

    if single == 1:
        ax1_curve.remove()
        ax2_curve.remove()
        ax1.legend()
        ax2.legend()

    margin_report[0], margin_report[1] = margin_report[1], margin_report[0]

    return elapsed_time, result, freq_out, margin_report, wc, type, spectrum_avg  # return margin and freq in case of failed
