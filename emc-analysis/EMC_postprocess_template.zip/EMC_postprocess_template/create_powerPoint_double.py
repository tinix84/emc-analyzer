import pptx  
import os

operting_points = ["OP3", "OP3A", "OP3B"]

DC_ports = ["LV", "HV"]
AC_ports = ["L1", "L2", "L3", "N"]

DUT = "OBC764"

date = "250530"

pptx_start_doc = r"single_master.pptx"

# Create a new PowerPoint presentation
prs = pptx.Presentation(pptx_start_doc)

# Set the path to the folder containing the images
folder_path = r"C:\Users\jfe01.BRUSA\Desktop\OBC7xx\OBC764\IVECO_EMC\data_best"

# Get the slide width and height
slide_width = prs.slide_width
slide_height = prs.slide_height

image_list = []
# Iterate over the files in the folder
for filename in os.listdir(folder_path):
  # Check if the file is an image
  if filename.endswith('.BMP') or filename.endswith('.bmp') or filename.endswith('.png') or filename.endswith('.jpg') or filename.endswith('.JPG'):
    image_list.append(filename)

print(image_list)

img_paths = [os.path.join(folder_path, image_list[i]) for i in range(0,int(len(image_list)))]

## DC ports
for op in operting_points:
  op = "_" + op + "_"
  for port in DC_ports:
    # Add the images to a new slide
    slide_layout = prs.slide_layouts[17]  # layout double image + text
    slide = prs.slides.add_slide(slide_layout)
    placeholders_img = [ph for ph in slide.placeholders if ph.placeholder_format.type == 18]
    placeholders_text = [ph for ph in slide.placeholders if ph.placeholder_format.type == 7]

    out = []
    for img in img_paths:
      if port in img and op in img:
        out.append(img)
        
    k = 0
    for img, ph in zip(out, placeholders_img):
      ph.insert_picture(img)
      subtitle = slide.placeholders[0]
      subtitle.text = port + " - " + op.replace("_", "")
      placeholders_text[k].text = img.split('\\')[-1].split('.')[0]
      k += 1

  ## AC ports
  #for op in operting_points:
  #  op = "_" + op + "_"
  for i in range(2):
    # Add the image to a new slide every two image
    print("new slides added!!")
    slide_layout = prs.slide_layouts[17]  # layout single image
    slide = prs.slides.add_slide(slide_layout)

    out = []
    for img in img_paths:
      if op in img:
        if DUT in img:
          if date in img:
            for port in AC_ports:
              if port in img:
                out.append(img)

    placeholders_img = [ph for ph in slide.placeholders if ph.placeholder_format.type == 18]
    placeholders_text = [ph for ph in slide.placeholders if ph.placeholder_format.type == 7]

    out.sort()
    
    if i==0:
      images = out[:-2]
    else:
      images = out[-2:]

    j = 0
    for img, ph in zip(images, placeholders_img):
      ph.insert_picture(img)
      subtitle = slide.placeholders[0]
      subtitle.text = "AC" + " - " + op.replace("_", "")
      placeholders_text[j].text = img.split('\\')[-1].split('.')[0]
      j += 1


# Save the PowerPoint presentation
prs.save(r'C:\Users\jfe01.BRUSA\Desktop\OBC7xx\OBC764\IVECO_EMC\presentation_double.pptx')

print("End")

