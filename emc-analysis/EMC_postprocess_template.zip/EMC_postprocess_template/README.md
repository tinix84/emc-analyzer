# EMC Postprocessing Guide 2.6.25 update

## Configuration

1. Install python 3.13.1 from https://www.python.org/ftp/python/3.13.1/python-3.13.1-amd64.exe. During the installation add python to the PATH. Check both check boxes when starting the installation (path and admin rights)
2. Install uv from https://docs.astral.sh/uv/getting-started/installation/ --> open power shell and copy paste the command: powershell -ExecutionPolicy ByPass -c "irm https://astral.sh/uv/install.ps1 | iex"
3. close power shell
4. sync one drive folder
5. generate a local copy (project folder)
6. open visual studio code and open your local stored project folder
7. Terminal -> New Terminal: Create a new virtual environment with: uv venv --python 3.13.1
8. Select the interpreter on VS code (in .venv folder), close all the terminals and restart VS code. (Ctrl+shift+p)
9. be sure to run windows terminal. you can select it in the lower right bar. see also: https://code.visualstudio.com/docs/terminal/profiles
10. Install the required packages using pip: uv pip install package_name . See also https://docs.astral.sh/uv/pip/packages/. 
    NOTE: pptx package is called python-pptx.
11. uv pip list to show the installed packages

Required packages: numpy, matplotlib, IPython, python-pptx

## Input Data
The data must be in txt format directly extracted from the NARDA application.
Once the data is available put it inside the working folder

## Comparision Generator
Run the EMC_plotting_LV.py script to generate the comparision plots.

### Input data selection
Copy and paste from the Measurement.txt file the operating points you want to compare.

```python
#########################################################
# General settings

# Enter the operating point title here
selection_of_titles = [" OP2_3P: AC 230V, 21.9A, LV: 12V, HV: 501V, 28.8A G2V 3Phase",
                       " OP5_3P: AC 230V, 2.6A, LV: 12V, HV: 860V, 2A G2V 3Phase",
                       " OP7_3P: AC 231V, 31.2A, LV: 12V, HV: 573V, 36A G2V 3Phase",
                       " OP8_3P: AC 234V, 8.5A, LV: 12V, HV: 573V, 10A G2V 3Phase"]
``` 

In the following snippet you can set additional features. \
NOTE: when plotting single spectrum (no comparison) the file_names entries must be the same and legend_entries entries must be both "". 

```python
HF_available_meas = ["HVpos", "HVneg", "LVpos", "LVneg"] # Enter the signals with HF data available, leave it empty if no HF mesurements available
savefig = 1  # 0 = not saving images, 1 = saving images into the assigned folder
plot_folder = "Comparison_plots/"  # plots folder
showfig = 0  # enables the figure show
show_limits = 0  # show the final figure
copy_to_external_folder = 0
ext_folder_path = r"C:\Users\jfe01.BRUSA\Desktop\OBC7xx\EMC results\Documentation\images\product"
rotate = 0  # rotate the image before copying it
typst_edit = 0  # generates the data structure to import images
images_filename = "typst.txt"
ppt = 1  # generate the powerpoint
single = 0  # the graph will be with a single trace (if 1 put the same file_names on file_names list
            # and leave the legend entries empty with "")


#####################################################################
total_elapsed_time  = 0
result = 0
fp = open("results.txt", "w")
# REAL POST PROCESSING
for k, op in enumerate(["3", "3A", "3B"]):
    # for each operating point defined
    for meas in ["HVpos", "HVneg", "LVpos", "LVneg", "L1", "L2", "L3", "N"]:
        # for each measurement

        # Define name of files to be plotted as well as plot order (no extension)
        # when plotting single spectrum (no comparison) both entries must be the same
        file_names = ["250430_OBC764_OP" + str(op) + "_" + str(meas),
                      "250502_OBC764_OP" + str(op) + "_" + str(meas)]
        print(f"processing: {file_names}")
        # when plotting single spectrum (no comparison) set legend_entries to ["",""]
        legend_entries = ["Standard",
                          "Jittering"]
        plot_order = [1, 1]
        plot_title = ["OBC764" + selection_of_titles[k] + " - " + meas]
        y_limit = [-10, 100]
        # Define parent folder; end with "/"
        parent_folder = "/"

        
        try:
            result = True
            xticks = [0.15, 1, 10, 108]
            elapsed_time, result, freq, margin, wc_violation, detector, spectrum_avg = pp(data_folder, file_names, plot_order, meas,
                    dir_path, legend_entries, savefig, showfig,
                    plot_title, plot_folder, HF_available_meas, single, meas)
        
            # Save the result into a file
            for res, f, mar,wc, det in zip(result, freq, margin, wc_violation, detector):
                fp.write(f"{file_names[1]} {res}: {f}MHz {mar:.2f}dBuV {wc:.3f}MHz {det} {spectrum_avg}dBuV\n")

            total_elapsed_time += elapsed_time

        except Exception as e:
            print(e)

print(f"Total elapsed time: {total_elapsed_time} [s]")
```

## Powerpoint Generator

### Comparision picture script

Set the folder_path and the save path, then run.

```python
import pptx  
import os

pptx_start_doc = r"single_master.pptx"

# Create a new PowerPoint presentation
prs = pptx.Presentation(pptx_start_doc)

# Set the path to the folder containing the images
folder_path = r"C:\Users\jfe01.BRUSA\Desktop\OBC7Bi\EMC_3phase\Comparison_plots"

# Get the slide width and height
slide_width = prs.slide_width
slide_height = prs.slide_height

image_list = []
# Iterate over the files in the folder
for filename in os.listdir(folder_path):
  # Check if the file is an image
  if filename.endswith('.BMP') or filename.endswith('.bmp') or filename.endswith('.png'):
    image_list.append(filename)

print(image_list)

for i in range(0,int(len(image_list))):
    # Add the image to a new slide
    slide_layout = prs.slide_layouts[18]  # layout single image
    slide = prs.slides.add_slide(slide_layout)
    img_path1 = os.path.join(folder_path, image_list[i])
    left = pptx.util.Cm(0)
    top = pptx.util.Cm(2.93)
    width = pptx.util.Cm(33.55)
    height = pptx.util.Cm(15.51)
    pic1 = slide.shapes.add_picture(img_path1, left, top, width=width, height=height)
    subtitle = slide.placeholders[0]
    subtitle.text = img_path1.split('\\')[-1].split('.')[0]

# Save the PowerPoint presentation
prs.save(r'C:\Users\jfe01.BRUSA\Desktop\OBC7Bi\EMC_3phase\presentation_new_comparison.pptx')

print("End")
```

This function is built-in the Comparison Generator script, please be careful when you set the destination folder.

### Original picture script

The same applies for this version, everything is just scaled to fit the image size :-p

```python
import pptx  
import os

pptx_start_doc = r"single_master.pptx"

# Create a new PowerPoint presentation
prs = pptx.Presentation(pptx_start_doc)

# Set the path to the folder containing the images
folder_path = r"C:\Users\jfe01.BRUSA\Desktop\OBC7Bi\EMC_3phase\150425\150425"

# Get the slide width and height
slide_width = prs.slide_width
slide_height = prs.slide_height

image_list = []
# Iterate over the files in the folder
for filename in os.listdir(folder_path):
  # Check if the file is an image
  if filename.endswith('.BMP') or filename.endswith('.bmp') or filename.endswith('.png'):
    image_list.append(filename)

print(image_list)

for i in range(0,int(len(image_list))):
    # Add the image to a new slide
    slide_layout = prs.slide_layouts[18]  # layout single image
    slide = prs.slides.add_slide(slide_layout)
    img_path1 = os.path.join(folder_path, image_list[i])
    left = pptx.util.Cm(6.81)
    top = pptx.util.Cm(3.04)
    width = pptx.util.Cm(19.33)
    height = pptx.util.Cm(15.25)
    pic1 = slide.shapes.add_picture(img_path1, left, top, width=width, height=height)
    subtitle = slide.placeholders[0]
    subtitle.text = img_path1.split('\\')[-1].split('.')[0]

# Save the PowerPoint presentation
prs.save(r'C:\Users\jfe01.BRUSA\Desktop\OBC7Bi\EMC_3phase\presentation_new.pptx')

print("End")
```

### Enanched Powerpoint Generator

This advanced version prints the results and suggests the frequency pole to adjust the filter behavior. Enter the correct file paths and run the script.

```python
import pptx  
import os

pptx_start_doc = r"single_master.pptx"

# Create a new PowerPoint presentation
prs = pptx.Presentation(pptx_start_doc)

# Set the path to the folder containing the images
folder_path = r"C:\Users\jfe01.BRUSA\Desktop\OBC7xx\OBC764\EMC"

# Get the slide width and height
slide_width = prs.slide_width
slide_height = prs.slide_height

image_list = []
# Iterate over the files in the folder
for filename in os.listdir(folder_path):
  # Check if the file is an image
  if filename.endswith('.BMP') or filename.endswith('.bmp') or filename.endswith('.png'):
    image_list.append(filename)

print(image_list)

for i in range(0,int(len(image_list))):
    # Add the image to a new slide
    slide_layout = prs.slide_layouts[10]  # layout single image
    slide = prs.slides.add_slide(slide_layout)
    img_path1 = os.path.join(folder_path, image_list[i])
    for shape in slide.placeholders:
       if shape.placeholder_format.type == 7:
          ph = shape
          break
       
    left = ph.left
    top = ph.top
    width = ph.width
    height = ph.height

    pic1 = slide.shapes.add_picture(img_path1, left, top, width=width, height=height)

    subtitle = slide.placeholders[0]
    subtitle.text = img_path1.split('\\')[-1].split('.')[0]

    ## Add text
    textbox = [s for s in slide.shapes if s.has_text_frame][1]
    textbox.text = "PASSED"

# Save the PowerPoint presentation
prs.save(r'C:\Users\jfe01.BRUSA\Desktop\OBC7xx\OBC764\EMC\presentation_new_bravo_jitter.pptx')

print("End")
```
