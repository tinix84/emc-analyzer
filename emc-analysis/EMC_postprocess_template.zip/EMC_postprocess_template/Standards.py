##############################
# STANDARD LIMITS DEFINTIONS #
##############################

import math

# LV: CISPR-25 class 2 limits
CISPR_25_range_f = [ 0.15, 0.3, 0.3, 0.53, 0.53, 1.8, 1.8, 5.9, 5.9, 6.2, 6.2,
                      26, 26, 28,  28,  30, 30, 41, 41, 68, 68, 88, 88, 108]
CISPR_25_2_average = [ 80,  80, 200,  200,   58,  58, 200, 200,  51,  51, 200,
                       200, 42, 42, 200, 200, 42, 42, 42, 42, 36, 36, 36, 36]
CISPR_25_2_peak    = [100, 100, 200,  200,   78,  78, 200, 200,  71,  71, 200,
                       200, 62, 62, 200, 200, 62, 62, 52, 52, 52, 52, 56, 56]

# LV: CISPR-25 class 3 limits
CISPR_25_3_average = [70, 70, 200, 200, 50, 50, 200, 200, 45, 45, 200, 200, 36,
                       36, 200, 200, 36, 36, 36, 36, 30, 30, 30, 30]
CISPR_25_3_peak    = [90, 90, 200, 200, 70, 70, 200, 200, 65, 65, 200, 200, 56,
                       56, 200, 200, 56, 56, 46, 46, 46, 46, 50, 50]

# LV: CISPR-25 class 4 limits
CISPR_25_4_average = [60, 60, 200, 200, 42, 42, 200, 200, 39, 39, 200, 200, 30,
                       30, 200, 200, 30, 30, 30, 30, 24, 24, 24, 24]
CISPR_25_4_peak    = [80, 80, 200, 200, 62, 62, 200, 200, 59, 59, 200, 200, 50,
                       50, 200, 200, 50, 50, 40, 40, 40, 40, 44, 44]

# LV: CISPR-25 class 5 limits
CISPR_25_5_average = [50,  50, 200,  200,   34,  34, 200, 200,  33,  33, 200,
                       200, 24, 24, 200, 200, 24, 24, 24, 24, 18, 18, 18, 18]
CISPR_25_5_peak    = [70,  70, 200,  200,   54,  54, 200, 200,  53,  53, 200,
                       200, 44, 44, 200, 200, 44, 44, 34, 34, 34, 34, 38, 38]

# AC: CISPR-22 class B limits
CISPR_AC_range_f = [0.15, 0.5, 0.5, 5, 5, 30]  # MHz
CISPR_AC_average = [56, 46, 46, 46, 50, 50]
CISPR_AC_peak    = [66, 56, 56, 56, 60, 60]

# HV: CISPR-25 class 3 (decoupling A5) limits
CISPR_HV_range_f = [0.15, 0.3, 0.3, 0.53, 0.53, 1.8, 1.8, 5.9, 5.9, 6.2, 6.2,
                     26, 26, 28, 28, 30, 30, 41, 41, 68, 68, 88, 88, 108]
CISPR_HV_average = [107, 107, 200, 200, 80, 80, 200, 200, 69, 69, 200, 200,
                     53, 53, 200, 200, 51, 51, 49, 49, 43, 43, 42, 42]
CISPR_HV_peak    = [127, 127, 200, 200, 100, 100, 200, 200, 89, 89, 200,
                     200, 73, 73, 200, 200, 71, 71, 59, 59, 59, 59, 62, 62]

def gain_dB_f(x1,x2, y1, y2):

    if (x2 - x1) == 0:
        return 0

    m = (y2-y1) / (math.log10(x2)-math.log10(x1))
    
    return m


def find_position(value, ls_x, ls_y):

    for i in range(len(ls_x)-1):
        if ls_x[i] <= value <= ls_x[i+1] or ls_x[i] >= value >= ls_x[i+1] :
            return ls_x[i],ls_x[i+1], ls_y[i], ls_y[i+1]
    return ls_x[0],ls_x[0], ls_y[0], ls_y[0]


def calculate_threshold(x_list, y_list, x):
    """ This function returns the threshold limit """

    #if x < min(x_list) or x > max(x_list):
    #    print(f"x: {x}, min: {min(x_list)}, max: {max(x_list)}")
    #    raise Exception
    if math.isnan(x):
        raise Exception
    
    xa,xb, ya,yb = find_position(x,x_list, y_list)  # np.unique(x_list))

    #print(f"il punto {x} sta tra {xa} e {xb} con {ya} e {yb}")
    gain = gain_dB_f(xa,xb, ya,yb)
    #print(f"gain: {gain}")

    return ya + gain*(x - xa)

if __name__ == "__main__":

    import numpy as np

    test_list= np.arange(CISPR_AC_range_f[0], CISPR_AC_range_f[-1], 0.1).tolist()
    print(f"test_list: {test_list}")
    print(f"CISPR_AC_range_f: {CISPR_AC_range_f}")
    print(f"CISPR_AC_average: {CISPR_AC_average}")
    print(f"test_list: {test_list}")
    for x in test_list:
        print(calculate_threshold(CISPR_AC_range_f, CISPR_AC_average, x))

    # calculate slopes

    
